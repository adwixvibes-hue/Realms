extends Control


func _on_start_pressed() -> void:
	$AnimationPlayer.play("Jump to game")
	await $AnimationPlayer.animation_finished
	get_tree().change_scene_to_file("res://Scenes/Main_Lab.tscn")


func _on_exit_pressed() -> void:
	get_tree().quit()


func _on_settings_2_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/settings.tscn")

	
