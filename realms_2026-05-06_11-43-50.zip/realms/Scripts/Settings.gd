extends Control


func _on_save_button_pressed() -> void:
	var selected_item = $OptionButton.selected
	GlobalVariables.camerafov = Vector2(float($OptionButton.get_item_text(selected_item)), float($OptionButton.get_item_text(selected_item)))
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")
