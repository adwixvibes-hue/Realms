extends Node
#Here we will put the global

var camerafov:Vector2
