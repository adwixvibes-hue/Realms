extends CharacterBody2D


const SPEED = 120.0
const JUMP_VELOCITY = -400.0

var menu_name: String = "إياد ليزيوم (ليزوم بالجزائرية معناها زلمة ههههه)"
var last_direction: String = "down"

var is_inside_machine: bool = false

@onready var effects_pivot: Node2D = $"effects pivot"
@onready var attack_detector: RayCast2D = $"Attack detector"
@onready var attack_animation: AnimatedSprite2D = $"effects pivot/attack_animation"
@onready var help: Label = $Help
@onready var anim: AnimatedSprite2D = $Texture

func _ready() -> void:
	attack_animation.stop()
	help.visible = false

func _process(delta: float) -> void:
	if not attack_animation.is_playing():
		effects_pivot.look_at(get_global_mouse_position())
		attack_detector.look_at(get_global_mouse_position())

	if Input.is_action_just_pressed("attack"):
		detect_attack()
		attack_animation.visible = true
		attack_animation.play("default")
		await attack_animation.animation_looped
		attack_animation.stop()
		attack_animation.visible = false

func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("Use") and is_inside_machine:
		show_current_menu()

	var direction_x := Input.get_axis("ui_left", "ui_right")
	var direction_y := Input.get_axis("ui_up", "ui_down")

	update_animation(direction_x, direction_y)

	var input_vector = Vector2(direction_x, direction_y)
	if input_vector.length() > 0:
		input_vector = input_vector.normalized()

	velocity.x = input_vector.x * SPEED
	velocity.y = input_vector.y * SPEED

	move_and_slide()

func update_animation(direction_x: float, direction_y: float):
	var is_moving = direction_x != 0 or direction_y != 0
	
	if not is_moving:
		match last_direction:
			"up":
				anim.play("Idle Up")
			"down":
				anim.play("Idle down")
			"left":
				anim.play("Idle_side")
			"right":
				anim.play("Idle_side")
		return

	if direction_y < 0:  
		anim.play("Walking Up")
		last_direction = "up"
	elif direction_y > 0:  
		anim.play("Walking Down")
		last_direction = "down"
	elif direction_x < 0:
		anim.flip_h = false
		anim.play("Walking side")
		last_direction = "left"
	elif direction_x > 0:
		anim.flip_h = true
		anim.play("Walking side")
		last_direction = "right"


func show_current_menu():
	var current_menu = load(str("res://Scenes/Menus/" + menu_name + ".tscn"))
	var instantiated_menu = current_menu.instantiate()
	$"../CanvasLayer/Menu parent".add_child(instantiated_menu)

#دالة كتبتها أنا عشان تظهر المساعدة
func show_help(text: String):
	help.visible = true
	help.text = text

func hide_help():
	help.visible = false

func detect_attack():
	if attack_detector.is_colliding():
		const loading_attack_effect = preload("res://Assets/Effects/Attack effect.tscn")
		var attack_effect = loading_attack_effect.instantiate()
		attack_effect.global_position = attack_detector.get_collision_point()
		attack_effect.look_at(attack_detector.global_position)
		get_parent().add_child(attack_effect)
