extends Control

@onready var resources_container: GridContainer = $Control/Resources/ScrollContainer/GridContainer
@onready var souls_container: GridContainer = $Control/Souls/ScrollContainer/GridContainer
@onready var potions_container: GridContainer = $Control/Potions/ScrollContainer/GridContainer

@onready var tabs = {
	"resources": $Control/Resources,
	"souls": $Control/Souls,
	"potions": $Control/Potions
}

@onready var anim: AnimationPlayer = $AnimationPlayer

@onready var resources_button: TextureButton = $Resources
@onready var souls_button: TextureButton = $Souls
@onready var potions_button: TextureButton = $Potions
@onready var exit: TextureButton = $Exit

var player_inventory: Array

func _ready() -> void:
	load_resources()

func clear_containers():
	for container in [resources_container, souls_container, potions_container]:
		for child in container.get_children():
			child.queue_free()

func load_items(type_filter: String, container: Control):
	clear_containers()
	
	for item: ItemData in player_inventory:
		if item.item_type == type_filter:
			var item_slot = Control.new()
			item_slot.custom_minimum_size = Vector2(64, 64)

			var btn = TextureButton.new()
			btn.texture_normal = item.item_icon
			btn.ignore_texture_size = true
			btn.stretch_mode = TextureButton.STRETCH_KEEP_ASPECT_CENTERED
			btn.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

			if type_filter == "Potion":
				btn.pressed.connect(func(): _on_potion_selected(item))
			
			item_slot.add_child(btn)

			if item.amount > 1:
				var lbl = Label.new()
				lbl.text = str(item.amount)
				lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
				lbl.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
				lbl.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
				lbl.add_theme_font_size_override("font_size", 14)
				lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
				item_slot.add_child(lbl)

			container.add_child(item_slot)

func _on_potion_selected(item: ItemData):
	var player = get_tree().get_first_node_in_group("Player")
	if player:
		player.selected_potion = item 
		print("تم اختيار بوشن: ", item.item_name)

func load_resources():
	switch_tab("resources")
	load_items("Resource", resources_container)

func load_souls():
	switch_tab("souls")
	load_items("Soul", souls_container)

func load_potions():
	switch_tab("potions")
	load_items("Potion", potions_container)

func switch_tab(tab_name: String):
	for t in tabs:
		tabs[t].visible = (t == tab_name)

func _on_recources_pressed() -> void:
	resources_button.disabled = true
	souls_button.disabled = false
	potions_button.disabled = false
	load_resources()



func _on_souls_pressed() -> void:
	resources_button.disabled = false
	souls_button.disabled = true
	potions_button.disabled = false
	load_souls()


func _on_potions_pressed() -> void:
	resources_button.disabled = false
	souls_button.disabled = false
	potions_button.disabled = true
	load_potions()

func _on_exit_pressed() -> void:
	get_tree().get_first_node_in_group("Player").movable = true
	anim.play_backwards("Load inventory")
	await anim.animation_finished
	queue_free()
