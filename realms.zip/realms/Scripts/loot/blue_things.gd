extends Area2D

@export var item_name: String = "blue_thing"
@export var item_type: String = "Resource"
@export var item_value: int = 10
@export var item_icon: Texture2D 

@onready var anim: AnimationPlayer = $anim

func _ready() -> void:
	anim.play("Droploot")

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		if body.has_method("add_to_inventory"):
			var item_data = {
				"name": item_name,
				"type": item_type,
				"value": item_value,
				"icon": item_icon
			}
			body.add_to_inventory(item_data)
			queue_free()
