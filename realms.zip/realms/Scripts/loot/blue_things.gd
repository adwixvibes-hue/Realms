extends Area2D

@export var item_info: ItemData
@onready var anim: AnimationPlayer = $anim

var follow_body = false
var current_body

func _process(delta: float) -> void:
	if follow_body:
		var dir = (current_body.global_position - global_position).normalized()
		position += delta * dir * 120

func _ready() -> void:
	anim.play("Droploot")

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		body.add_to_inventory(item_info)
		anim.play("Despawn")
		await anim.animation_finished
		queue_free()


func _on_player_detector_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		follow_body = true
		current_body = body


func _on_player_detector_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		follow_body = false
		current_body = null
