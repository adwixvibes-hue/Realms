extends Resource
class_name ItemData

@export var item_name: String = ""
@export var item_icon: Texture2D
@export var item_value: int = 0
@export_multiline var description: String = ""
