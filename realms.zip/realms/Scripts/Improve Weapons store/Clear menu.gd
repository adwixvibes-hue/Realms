#potion creation menu scene script
extends Control

@export var all_recipes: Array[PotionRecipe] = []

@onready var craft_list: VBoxContainer = $ScrollContainer/VBoxContainer 

var player_ref: Node

func _ready() -> void:
	player_ref = get_tree().get_first_node_in_group("Player")
	suggest_potions_based_on_the_player_inventory()

func suggest_potions_based_on_the_player_inventory():
	for child in craft_list.get_children():
		child.queue_free()

	for recipe in all_recipes:
		if can_craft(recipe, player_ref.inventory):
			create_craft_button(recipe)

func create_craft_button(recipe: PotionRecipe):
	var btn = Button.new()
	btn.text = "صناعة: " + recipe.potion_name
	btn.pressed.connect(func(): _on_craft_confirmed(recipe))
	craft_list.add_child(btn)

func _on_craft_confirmed(recipe: PotionRecipe):
	craft_potion(recipe, player_ref)
	suggest_potions_based_on_the_player_inventory()

func can_craft(recipe: PotionRecipe, player_inventory: Array[ItemData]) -> bool:
	for required_item: ItemData in recipe.needs_for_potion.keys():
		var required_amount = recipe.needs_for_potion[required_item]
		var found_amount = 0
		for item in player_inventory:
			if item.item_name == required_item.item_name:
				found_amount = item.amount
				break
		
		if found_amount < required_amount:
			return false
			
	return true

func craft_potion(recipe: PotionRecipe, player: Node):
	if can_craft(recipe, player.inventory):
		# 1. خصم المكونات
		for required_item: ItemData in recipe.needs_for_potion.keys():
			var required_amount = recipe.needs_for_potion[required_item]
			for item in player.inventory:
				if item.item_name == required_item.item_name:
					item.amount -= required_amount
					if item.amount <= 0:
						player.inventory.erase(item)
					break
		if recipe.result_item:
			var new_potion = recipe.result_item.duplicate()
			new_potion.amount = 1
			player.add_to_inventory(new_potion)
			print("تم صنع: ", recipe.potion_name)

func _on_button_pressed() -> void:
	queue_free()
