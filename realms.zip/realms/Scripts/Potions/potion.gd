extends Control

@onready var progress_bar: ProgressBar = $ProgressBar

var potion: String = ""

func _ready() -> void:
	hide()

func _process(delta: float) -> void:

	if Input.is_action_just_pressed("Usepotion"):
		use_potion()

	var player = get_tree().get_first_node_in_group("Player")
	if player:
		var has_potion = false
		for item in player.inventory:
			if item.item_type == "Potion" and item.amount > 0:
				has_potion = true
				break
		
		if has_potion:
			show()
		else:
			hide()

func _on_texture_button_pressed() -> void:
	var ev = InputEventAction.new()
	ev.action = "Usepotion"
	ev.pressed = true
	Input.parse_input_event(ev)

func use_potion():
	var player = get_tree().get_first_node_in_group("Player")
	if player and player.selected_potion:
		var current_p = player.selected_potion
		
		player.use_potion(current_p.item_name)
		var duration = current_p.item_value
		if duration <= 0: duration = 1
		
		progress_bar.value = 100
		var step = 100.0 / duration
		
		for i in range(duration):
			await get_tree().create_timer(1).timeout
			progress_bar.value -= step
		
		player.potion_enabled = false
		progress_bar.value = 100
	else:
		print("لم يتم اختيار بوشن من الحقيبة بعد!")
