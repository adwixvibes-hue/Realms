extends Control

@export var dialogues: Array[String] = [
	"[center][b]مرحبا بك![/b][/center]",
	"هذا [color=yellow]نظام حوارات[/color] جميل 😎",
	"يمكنك تعديله من Inspector بسهولة!"
]

@export var typing_speed: float = 0.03
@export var auto_start: bool = true
@export var line_delay: float = 1.5

@onready var label: RichTextLabel = $RichTextLabel

var current_index := 0
var is_typing := false

func _ready():
	label.visible_characters = 0
	label.bbcode_enabled = true
	
	if auto_start:
		start_dialogue()

func start_dialogue():
	current_index = 0
	show_line()

func show_line():
	if current_index >= dialogues.size():
		hide()
		get_tree().get_first_node_in_group("Player").movable = true
		return
	
	label.text = dialogues[current_index]
	label.visible_characters = 0
	
	is_typing = true
	type_text()

func type_text():
	while label.visible_characters < label.get_total_character_count():
		label.visible_characters += 1
		await get_tree().create_timer(typing_speed).timeout
	
	is_typing = false

	await get_tree().create_timer(line_delay).timeout

	current_index += 1
	show_line()

func _input(event):
	if event.is_action_pressed("ui_accept"):
		if is_typing:
			label.visible_characters = label.get_total_character_count()
			is_typing = false
		else:
			current_index += 1
			show_line()
