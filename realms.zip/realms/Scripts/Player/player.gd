extends CharacterBody2D


const SPEED = 80
const dash_speed = 1000
const JUMP_VELOCITY = -400.0
var knockback_velocity := Vector2.ZERO

var menu_name: String = "إياد ليزيوم (ليزوم بالجزائرية معناها زلمة ههههه)"
var last_direction: String = "down"

var is_inside_machine: bool = false
var movable: bool = true
var potion_enabled: bool = false

@onready var effects_pivot: Node2D = $"effects pivot"
@onready var attack_detector: RayCast2D = $"Attack detector"
@onready var attack_animation: AnimatedSprite2D = $"effects pivot/attack_animation"
@onready var help: Label = $Help
@onready var anim: AnimatedSprite2D = $Texture

var inventory: Array[ItemData] = []
var selected_potion: ItemData = null

func _ready() -> void:
	inventory = GlobalVariables._inventory
	attack_animation.stop()
	help.visible = false

func _process(delta: float) -> void:

	GlobalVariables._inventory = inventory

	if Input.is_action_just_pressed("inventory"):
		open_inventory()

	if Input.is_action_just_pressed("ui_accept"):
		get_tree().change_scene_to_file("res://Scenes/Main_Lab.tscn")

	if not attack_animation.is_playing():
			if not DisplayServer.is_touchscreen_available():
				effects_pivot.look_at(get_global_mouse_position())
				attack_detector.look_at(get_global_mouse_position())
			else:
				var joystick_vector = get_parent().get_node("CanvasLayer").get_node("Touch input").get_node("joystick").get_output_vector()
				if joystick_vector.length() > 0.1:
					var target_angle = joystick_vector.angle()
					effects_pivot.rotation = target_angle
					attack_detector.rotation = target_angle

	if Input.is_action_just_pressed("attack"):
		detect_attack(delta)
		attack_animation.visible = true
		attack_animation.play("default")
		await attack_animation.animation_looped
		attack_animation.stop()
		attack_animation.visible = false

	if not movable:
		$"../CanvasLayer/ColorRect".hide()
		$"../CanvasLayer/SubViewportContainer".hide()
		$"../CanvasLayer/Touch input".hide()
	else:
		$"../CanvasLayer/ColorRect".show()
		$"../CanvasLayer/SubViewportContainer".show()
		$"../CanvasLayer/Touch input".show()

func _physics_process(delta: float) -> void:

	if Input.is_action_just_pressed("Dash") and movable and potion_enabled:
		var dir = (global_position - get_global_mouse_position()).normalized()
		knockback_velocity = dir * dash_speed

	if Input.is_action_just_pressed("Use") and is_inside_machine:
		show_current_menu()

	var direction_x := Input.get_axis("Left", "Right")
	var direction_y := Input.get_axis("Up", "Down")

	update_animation(direction_x, direction_y)

	var input_vector = Vector2(direction_x, direction_y)
	if input_vector.length() > 0:
		input_vector = input_vector.normalized()

	velocity = (input_vector * SPEED) + knockback_velocity

	knockback_velocity = lerp(knockback_velocity, Vector2.ZERO, 0.24)

	move_and_slide()

func update_animation(direction_x: float, direction_y: float):
	var is_moving = direction_x != 0 or direction_y != 0
	
	if not is_moving:
		match last_direction:
			"up":
				anim.play("Idle Up")
			"down":
				anim.play("Idle down")
			"left":
				anim.play("Idle_side")
			"right":
				anim.play("Idle_side")
		return

	if direction_y < 0:  
		anim.play("Walking Up")
		last_direction = "up"
	elif direction_y > 0:  
		anim.play("Walking Down")
		last_direction = "down"
	elif direction_x < 0:
		anim.flip_h = false
		anim.play("Walking side")
		last_direction = "left"
	elif direction_x > 0:
		anim.flip_h = true
		anim.play("Walking side")
		last_direction = "right"


func show_current_menu():
	var current_menu = load(str("res://Scenes/Menus/" + menu_name + ".tscn"))
	var instantiated_menu = current_menu.instantiate()
	$"../CanvasLayer/Menu parent".add_child(instantiated_menu)

#دالة كتبتها أنا عشان تظهر المساعدة
func show_help(text: String):
	help.visible = true
	help.text = text

func hide_help():
	help.visible = false

func detect_attack(delta):

	if attack_detector.is_colliding():
		var target = attack_detector.get_collider()
		var dir = global_position.direction_to(attack_detector.get_collision_point())
		knockback_velocity = -dir * (SPEED * 1.5)
		shake()
		if target.is_in_group("Character"):
			target.knockback_velocity = dir * (SPEED * 1.5)

		if target.is_in_group("Enemy"):
			target.got_damage()

		const loading_attack_effect = preload("res://Assets/Effects/Attack effect.tscn")
		var attack_effect = loading_attack_effect.instantiate()
		attack_effect.global_position = attack_detector.get_collision_point()
		
		attack_effect.look_at(attack_detector.global_position)
		get_parent().add_child(attack_effect)

func shake():
	create_tween().tween_method(func(x): $Camera2D.offset = Vector2(randf_range(-x,x), randf_range(-x,x)), 3, 0, 0.3)

func add_to_inventory(data: ItemData):
	for item in inventory:
		if item.item_name == data.item_name:
			item.amount += 1 
			return 

	var new_item = data.duplicate() 
	new_item.amount = 1
	inventory.append(new_item)

func open_inventory():
	if movable:
		movable = false
		var preload_invetory = preload("res://Scenes/inventory.tscn")
		var inventory_menu = preload_invetory.instantiate()
		inventory_menu.player_inventory = inventory
		get_parent().get_node("CanvasLayer").add_child(inventory_menu)

func use_potion(potion_name: String):
	for item in inventory:
		if item.item_name == potion_name and item.amount > 0:
			item.amount -= 1
			if item.amount <= 0:
				inventory.erase(item)
			potion_enabled = true
			return
