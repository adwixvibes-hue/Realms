extends CharacterBody2D

@export var speed = 60
@onready var nav_agent: NavigationAgent2D = $NavigationAgent2D
@onready var progress_bar: ProgressBar = $ProgressBar
@onready var anim: AnimationPlayer = $AnimationPlayer
var knockback_velocity := Vector2.ZERO
var health = 100
@onready var player = get_tree().get_first_node_in_group("Player")

@export var min_loot: int = 1
@export var max_loot: int = 3

@export var loot_templates: Array[PackedScene] = []

func _process(delta: float) -> void:
	progress_bar.value = health

func _physics_process(_delta):
	if player:
		nav_agent.target_position = player.global_position
	if nav_agent.is_navigation_finished():
		return
	var next_path_pos = nav_agent.get_next_path_position()
	var direction = global_position.direction_to(next_path_pos)
	velocity = direction * speed + knockback_velocity
	knockback_velocity = lerp(knockback_velocity, Vector2.ZERO, 0.1)
	move_and_slide()

func drop_loot():
	if loot_templates.is_empty(): return

	var attempts = randi_range(min_loot, max_loot)

	for i in range(attempts):
		var random_item_scene = loot_templates.pick_random()
		var temp_instance = random_item_scene.instantiate()

		var item_data = temp_instance.item_info 
		var roll = randf_range(0, 100)
		
		if roll <= item_data.drop_chance:
			get_parent().add_child(temp_instance)
			temp_instance.global_position = global_position + Vector2(randf_range(-20,20), randf_range(-20,20))
		else:
			temp_instance.queue_free()

func got_damage():
	flash()
	health -= 40
	if health <= 0:
		die()

func flash():
	anim.play("flash")
	await anim.animation_finished
	anim.stop()

func die():
	drop_loot()
	queue_free()
