extends Node
#Here we will put the global

var camerafov:Vector2
var _inventory: Array[ItemData]
