@tool
class_name VirtualJoystick
extends Control

@onready var base: TextureRect = get_node_or_null("Base")
@onready var knob: TextureRect = get_node_or_null("Base/Knob")

@export_group("Input Actions")

@export var action_left: String = "Left"
@export var action_right: String = "Right"
@export var action_up: String = "Up"
@export var action_down: String = "Down"

@export_group("Textures")
@export var base_texture: Texture2D:
	set(v):
		base_texture = v
		if base: base.texture = v
@export var knob_texture: Texture2D:
	set(v):
		knob_texture = v
		if knob: knob.texture = v

@export_group("Settings")
@export var disabled := false:
	set(v):
		disabled = v
		if disabled: _reset_knob()

@export var only_in_touch_screen := false
@export var deadzone_px := 15.0
@export var max_distance_px := 100.0

# متغيرات داخلية
var _finger_id: int = -1
var _output_vector := Vector2.ZERO
var _is_dragging := false

func _ready():
	if Engine.is_editor_hint(): return
	
	# التحقق من شاشة اللمس
	if only_in_touch_screen and not DisplayServer.is_touchscreen_available():
		visible = false
		process_mode = PROCESS_MODE_DISABLED
		return
	
	# إعدادات الماوس واللمس للعقد الفرعية
	if base: base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if knob: knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	mouse_filter = Control.MOUSE_FILTER_STOP
	
	_reset_knob()

func _gui_input(event: InputEvent):
	if Engine.is_editor_hint() or disabled: return
	
	# دعم اللمس والماوس (إذا تم تفعيل محاكاة اللمس في إعدادات المشروع)
	if event is InputEventScreenTouch:
		if event.pressed and not _is_dragging:
			_finger_id = event.index
			_is_dragging = true
			_update_joystick(event.position)
		elif not event.pressed and event.index == _finger_id:
			_reset_knob()
			
	elif event is InputEventScreenDrag and event.index == _finger_id:
		_update_joystick(event.position)
	
	# دعم الماوس المباشر للاختبار السريع
	elif event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			_is_dragging = true
			_update_joystick(event.position)
		elif not event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
			_reset_knob()
	elif event is InputEventMouseMotion and _is_dragging:
		_update_joystick(event.position)

func _update_joystick(input_pos: Vector2):
	var center = size / 2
	var raw_vector = input_pos - center
	var distance = raw_vector.length()
	
	if distance < deadzone_px:
		_output_vector = Vector2.ZERO
	else:
		var direction = raw_vector.normalized()
		var strength = clamp((distance - deadzone_px) / (max_distance_px - deadzone_px), 0.0, 1.0)
		_output_vector = direction * strength
	
	# تحديث شكل المقبض
	if knob:
		var visual_dist = min(distance, max_distance_px)
		knob.position = (center + raw_vector.normalized() * visual_dist) - (knob.size / 2)
	
	_feed_input_system()

func _reset_knob():
	_output_vector = Vector2.ZERO
	_is_dragging = false
	_finger_id = -1
	_feed_input_system()
	if knob:
		knob.position = (size / 2) - (knob.size / 2)

func _feed_input_system():
	_send_action(action_right, _output_vector.x > 0, max(0, _output_vector.x))
	_send_action(action_left, _output_vector.x < 0, max(0, -_output_vector.x))
	_send_action(action_down, _output_vector.y > 0, max(0, _output_vector.y))
	_send_action(action_up, _output_vector.y < 0, max(0, -_output_vector.y))

func _send_action(name: String, pressed: bool, strength: float):
	if name == "" or not InputMap.has_action(name): return
	var ev = InputEventAction.new()
	ev.action = name
	ev.pressed = pressed
	ev.strength = strength
	Input.parse_input_event(ev)

func get_output_vector() -> Vector2:
	return _output_vector
