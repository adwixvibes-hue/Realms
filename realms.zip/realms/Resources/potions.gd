extends Resource
class_name PotionRecipe

@export_group("Potion Info")
@export var potion_name: String = ""
@export var potion_icon: Texture2D

@export_group("Crafting Requirements")
@export var needs_for_potion: Dictionary[ItemData, int] = {}

@export_group("Result")
@export var result_item: ItemData
