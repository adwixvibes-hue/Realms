extends Resource
class_name ItemData

@export_enum("Resource", "Soul", "Potion") var item_type: String = "Resource"

@export var item_name: String = ""
@export var item_icon: Texture2D
@export var item_value: int = 0
@export_multiline var description: String = ""
@export var amount: int = 1
@export_range(0, 100) var drop_chance: float = 50.0
