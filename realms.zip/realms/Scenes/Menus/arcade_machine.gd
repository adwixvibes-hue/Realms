extends Control

@onready var lever_texture: AnimatedSprite2D = $"Lever/Lever texture"

func _ready() -> void:
	pass

func _process(delta: float) -> void:
	pass


func _on_lever_pressed() -> void:
	lever_texture.play("default")
	await lever_texture.animation_looped
	lever_texture.stop()
	


func _on_button_pressed() -> void:
	queue_free()


func _on_go_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/Fight arena/Grass arena.tscn")
